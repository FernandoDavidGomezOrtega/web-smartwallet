<h1>Crear nueva categoría</h1>

<div id='' class='row'>
  <div id='' class='col-10 offset-1'>
    <form class="" action="<?= base_url ?>categoria/save" method="post" name="">
      <div class="form-group">
        <label for="nombre">Nombre de la categoría</label>
        <input type="text" name="nombre" id="" value="" required>
      </div>

      <button type="submit" class="btn btn-primary white-letters">Guardar</button>
    </form>
  </div>
</div>